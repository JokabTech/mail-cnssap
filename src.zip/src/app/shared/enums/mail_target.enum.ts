export enum MailTarget {
  ADMIN_ASSISTANT = 'adminAssistant',
  SENIOR_ASSISTANT = 'seniorAssistant',
  DIRECTOR = 'director',
}
