export class Role {
   constructor(
    public id: number | undefined,
    public name: string
  ) { }
}
