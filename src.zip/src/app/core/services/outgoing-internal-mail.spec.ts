import { TestBed } from '@angular/core/testing';

import { OutgoingInternalMail } from './outgoing-internal-mail';

describe('OutgoingInternalMail', () => {
  let service: OutgoingInternalMail;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OutgoingInternalMail);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
