export enum Tabs {
  INITIAL = 'initial',
  ANNOTATED = 'annotated',
  ALL = 'all',
  TREATED = 'treated',
  TO_PROCESS = 'to-process',
}
