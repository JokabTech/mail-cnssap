import { Department } from './department';

export interface Mail {
  id: number;
  subject: string;
  scanned_document?: string;
  mail_date: Date;
  create_at: Date;
  update_at: Date;
  delete_at?: Date;
  department: Department;
}
