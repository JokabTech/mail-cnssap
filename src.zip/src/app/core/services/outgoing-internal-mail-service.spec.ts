import { TestBed } from '@angular/core/testing';

import { OutgoingInternalMailService } from './outgoing-internal-mail-service';

describe('OutgoingInternalMailService', () => {
  let service: OutgoingInternalMailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OutgoingInternalMailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
