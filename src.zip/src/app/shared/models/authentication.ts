
export class Authentication {
  constructor(
    public full_name: string,
    public authorization: string,
  ) { }
}
