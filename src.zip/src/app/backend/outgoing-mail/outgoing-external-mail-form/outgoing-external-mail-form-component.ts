import { Component } from '@angular/core';

@Component({
  selector: 'app-outgoing-external-mail-form-component',
  imports: [],
  templateUrl: './outgoing-external-mail-form-component.html',
  styleUrl: './outgoing-external-mail-form-component.scss'
})
export class OutgoingExternalMailFormComponent {

}
