import { Component } from '@angular/core';

@Component({
  selector: 'app-incoming-externa-mail-detail-component',
  imports: [],
  templateUrl: './incoming-externa-mail-detail-component.html',
  styleUrl: './incoming-externa-mail-detail-component.scss'
})
export class IncomingExternaMailDetailComponent {

}
