import { Component } from '@angular/core';

@Component({
  selector: 'app-incoming-interna-mail-detail-component',
  imports: [],
  templateUrl: './incoming-interna-mail-detail-component.html',
  styleUrl: './incoming-interna-mail-detail-component.scss'
})
export class IncomingInternaMailDetailComponent {

}
