export class Header {
  constructor(
    public title: string,
    public subTitle: string,
    public icon: string
  ) {}
}
