import { MatDialogActions, MatDialogClose, MatDialogContent, MatDialogTitle } from '@angular/material/dialog';

export const DialogImports = [
  MatDialogContent,
  MatDialogActions,
  MatDialogClose,
  MatDialogTitle
];
