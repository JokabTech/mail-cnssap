import { Component } from '@angular/core';

@Component({
  selector: 'app-incoming-internal-mails-table-component',
  imports: [],
  templateUrl: './incoming-internal-mails-table-component.html',
  styleUrl: './incoming-internal-mails-table-component.scss'
})
export class IncomingInternalMailsTableComponent {

}
