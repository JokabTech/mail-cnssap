import { TestBed } from '@angular/core/testing';

import { OutgoingExternalMail } from './outgoing-external-mail';

describe('OutgoingExternalMail', () => {
  let service: OutgoingExternalMail;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OutgoingExternalMail);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
