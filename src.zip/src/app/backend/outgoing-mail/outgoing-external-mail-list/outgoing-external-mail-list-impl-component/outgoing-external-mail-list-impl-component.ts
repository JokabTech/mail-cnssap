import { Component, inject } from '@angular/core';
import { ToolbarComponent } from '../../../incoming-mail/chunks/toolbar/toolbar-component';
import { StateService } from '../../../../core/services/state.service';
import { Header } from '../../../../shared/models/header';
import { SearchBarComponent } from '../../../incoming-mail/chunks/search-bar/search-bar-component';
import { Criteria } from '../../../../shared/models/criteria';

@Component({
  selector: 'app-outgoing-external-mail-list-impl-component',
  imports: [
    ToolbarComponent,
    SearchBarComponent
  ],
  templateUrl: './outgoing-external-mail-list-impl-component.html',
  styleUrl: './outgoing-external-mail-list-impl-component.scss'
})
export class OutgoingExternalMailListImplComponent {
  protected stateService = inject(StateService);

  constructor() {
    this.stateService.setHeader(new Header('COURRIERS SORTANTS EXTERNES', 'Liste des correspondances externes sortants', 'flight_land'));
  }


  onSelectTab(tab: string, isNewTab = false) {
    console.log(tab);
  }

  onActionButton(tab: string) {
  }

  onSearchChanged(criteria: Criteria) {
    console.log(criteria);
  }
}
