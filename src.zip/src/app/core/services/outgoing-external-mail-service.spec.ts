import { TestBed } from '@angular/core/testing';

import { OutgoingExternalMailService } from './outgoing-external-mail-service';

describe('OutgoingExternalMailService', () => {
  let service: OutgoingExternalMailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OutgoingExternalMailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
